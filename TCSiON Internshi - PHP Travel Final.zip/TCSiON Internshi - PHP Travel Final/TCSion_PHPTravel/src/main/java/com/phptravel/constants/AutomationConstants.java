package com.phptravel.constants;

public class AutomationConstants
{
	public static final String INVALID_LOGIN_MESSAGE = "Wrong credentials. try again!";
	public static final String INVALID_LOGIN_MESSAGE1 = "Invalid Login Credentials";
	public static final String NULL_LOGIN__MESSAGE = "Please fill out this field.";
	public static final String NULL_LOGIN__MESSAGE_S_EMAIL = "The Email field is required.";
	public static final String NULL_LOGIN__MESSAGE_S_PSWD = "The Password field is required.";
	
	public static final String DASHBOARD_TEXT = "Dashboard";
	public static final String SALES_TEXT = "Sales overview & summary";
	public static final String REVENUE_BREAKDOWN_TEXT="Revenue Breakdown 2022";
	
	public static final String PROFILE_UPDATED_MSG="Profile updated successfully.";
}

package com.phptravel.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.phptravel.testbase.TestBase;

public class AgentLoginPg extends TestBase
{
	CustomerLoginPg objC_LoginPg;
	
	@FindBy(xpath="//*[@id='Main']/section[1]//following::a[contains(text(),'Agent')]")
	WebElement agentBtn;
	@FindBy(xpath="//input[@name='email']")
	WebElement email;
	@FindBy(xpath="//input[@name='password']")
	WebElement password;
	@FindBy(xpath="//div[@class='btn-box pt-3 pb-4']/button[@type='submit']")
	WebElement loginBtn;
	@FindBy(xpath="//div[@class='alert alert-danger failed']")
	WebElement invalidCredentialMsg;
	
	public AgentLoginPg()
	{

		PageFactory.initElements(driver, this);
	}

	public void clickAgent()
	{
		agentBtn.click();
	}
	public void setEmail(String emailId)
	{
		email.sendKeys(emailId);
	}
	public void setPassword(String pass)
	{
		password.sendKeys(pass);
	}
	public AgentHomePg clickLogin()
	{
		loginBtn.click();
		return new AgentHomePg();
	}
	public String invalidLoginMsg()
	{
		return invalidCredentialMsg.getText();
	}
	public String nullEmailErrorMsg()
	{
		return email.getAttribute("validationMessage");
	}
	public String nullPassErrorMsg()
	{
		return password.getAttribute("validationMessage");
	}
	public void clearTB()
	{
		email.clear();
		password.clear();
	}
	
}

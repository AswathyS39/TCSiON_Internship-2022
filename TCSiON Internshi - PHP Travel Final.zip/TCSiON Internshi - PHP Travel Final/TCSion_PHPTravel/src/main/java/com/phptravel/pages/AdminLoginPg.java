package com.phptravel.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.phptravel.testbase.TestBase;

public class AdminLoginPg extends TestBase
{
	@FindBy(xpath="//*[@id='Main']/section[1]//following::a[contains(text(),'Admin')]")
	WebElement adminBtn;
	@FindBy(xpath="//input[@name='email']")
	WebElement email;
	@FindBy(xpath="//input[@name='password']")
	WebElement password;
	@FindBy(xpath="//button[@type='submit']")
	WebElement loginBtn;
	@FindBy(xpath="//div[@class='alert alert-danger loading wow fadeIn animated animated']")
	WebElement invalidCredentialMsg;

	
	public AdminLoginPg()
	{
		PageFactory.initElements(driver, this);
	}

	public void clickAdmin()
	{
		adminBtn.click();
	}
	public void setEmail(String emailId)
	{
		email.sendKeys(emailId);
	}
	public void setPassword(String pass)
	{
		password.sendKeys(pass);
	}
	public AdminHomePg clickLogin()
	{
		loginBtn.click();
		return new AdminHomePg();
	}
	public String invalidLoginMsg()
	{
		return invalidCredentialMsg.getText();
	}
	public String nullEmailErrorMsg()
	{
		return invalidCredentialMsg.getText();
	}
	public String nullPassErrorMsg()
	{
		return invalidCredentialMsg.getText();
	}
	public void clearTB()
	{
		email.clear();
		password.clear();
	}
}
package com.phptravel.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.phptravel.testbase.TestBase;

public class AgentHotelCurrencyPg extends TestBase
{
	@FindBy(id = "currency")
	WebElement currencyDD;
	@FindBy(xpath="//ul[@aria-labelledby='currency']//li[7]//a")
	WebElement inr;

	@FindBy(xpath="//a[text()='Hotels']")
	WebElement hotelsLink;	

	@FindBy(xpath="//span[@title=' Search by City']")
	WebElement citySearch;
	@FindBy(xpath="//input[@type='search']")
	WebElement citySearchTB;
	@FindBy(xpath="//ul[@role='listbox']//li")
	List <WebElement> citySuggestionTotalList;
	@FindBy(xpath = "//input[@name='checkin']")
	WebElement checkInBox;
	@FindBy(xpath = "//*[@id='fadein']//following::table/thead/tr[1]/th[2]")
	WebElement yearMonth;
	@FindBy(xpath = "//*[@id='fadein']//following::tr[1]/th[3]/i")
	WebElement nextArrow;
	@FindBy(xpath = "//span[@class='ladda-label']")
	WebElement searchBtn;
	
	@FindBy(xpath = "//section[@id='data']//ul//li//following::p[@class='card-meta']")
	List<WebElement> verifyHotel;
	
	
	@FindBy(xpath="//button[contains(text(),'Account')]")
	WebElement accountDD;
	@FindBy(xpath="//a[contains(text(),' Logout')]")
	WebElement logoutLink;
	
	
	public AgentHotelCurrencyPg()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String currencyINR() throws Exception
	{
		currencyDD.click();
		Thread.sleep(1000);
		inr.click();
		return currencyDD.getText();
	}
	public void searchHotels(String cityName, String selectCity, String yearM, String dateIn, String dateOut) throws Exception
	{
		hotelsLink.click();
		citySearch.click();	
		Thread.sleep(1000);
		citySearchTB.sendKeys(cityName);
		Thread.sleep(2000);
		for(int i=0;i<citySuggestionTotalList.size();i++)
		{
			//System.out.println("City Search List: "+citySuggestionTotalList.get(i).getText());
			if(citySuggestionTotalList.get(i).getText().contains(selectCity))
			{
				System.out.println("Selected City : "+citySuggestionTotalList.get(i).getText());
				Thread.sleep(2000);
				citySuggestionTotalList.get(i).click();
				Thread.sleep(2000);
				break;
			}
		}		
		checkInBox.click();
		Thread.sleep(2000);
		while(true)
		{
			if((yearMonth.getText()).equals(yearM))
			{
				break;
			}
			else
			{
				nextArrow.click();
			}
		}
		driver.findElement(By.xpath("//*[@id='fadein']/div[3]/div[1]/table/tbody/tr/td[contains(text(),"+dateIn+")]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[4]/div[1]/table/tbody/tr/td[contains(text(),"+dateOut+")]")).click();
		Thread.sleep(1000);
		searchBtn.click();
		Thread.sleep(1000);	
		
		//Search Result Verification
		
		for(int i=1;i<=verifyHotel.size();i++)
		{
			String place=driver.findElement(By.xpath("//section[@id='data']//ul//li//following::p[@class='card-meta']["+i+"]")).getText();
			if(place.equalsIgnoreCase(cityName))
			{
				Assert.assertTrue(true, "Displaying the Hotels in "+place+"");
			}
			else
			{
				Assert.assertTrue(false, "Displaying the Hotels in "+place+". Wrong Place!!!");				
			}
			System.out.println("Displaying the Hotels in "+place+"");
		}
		
	}
	public String clickLogout() throws Exception
	{
		accountDD.click();
		Thread.sleep(1000);
		logoutLink.click();	
		Thread.sleep(1000);
		return driver.getCurrentUrl();
	}
}

package com.phptravel.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.phptravel.testbase.TestBase;

public class CustomerLoginPg extends TestBase
{

	@FindBy(xpath="//*[@id='Main']/section[1]//following::a[contains(text(),'Customer')]")
	public WebElement customerBtn;
	@FindBy(xpath="//input[@placeholder='Email']")
	public WebElement email;
	@FindBy(xpath="//input[@name='password']")
	public WebElement password;
	@FindBy(xpath="//div[@class='btn-box pt-3 pb-4']/button[@type='submit']")
	public WebElement loginBtn;
	@FindBy(xpath="//div[@class='alert alert-danger failed']")
	public WebElement invalidCredentialMsg;
	
	public CustomerLoginPg()
	{
		PageFactory.initElements(driver, this);
	}

	public String clickCustomer()
	{
		customerBtn.click();
		return driver.getCurrentUrl();
	}
	public void setEmail(String emailId)
	{
		email.sendKeys(emailId);
	}
	public void setPassword(String pass)
	{
		password.sendKeys(pass);
	}
	public CustomerHomePg clickLogin()
	{
		loginBtn.click();
		return new CustomerHomePg();
	}
	public String invalidLoginMsg()
	{
		return invalidCredentialMsg.getText();
	}
	public String nullEmailErrorMsg()
	{
		return email.getAttribute("validationMessage");
	}
	public String nullPassErrorMsg()
	{
		return password.getAttribute("validationMessage");
	}
	public void clearTB()
	{
		email.clear();
		password.clear();
	}
}

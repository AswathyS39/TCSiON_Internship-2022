package com.phptravel.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.phptravel.testbase.TestBase;

public class AdminHomePg extends TestBase
{

	@FindBy(xpath="//li[@class='nav-item']//a[text()='Bookings']")
	WebElement Bookings;
	@FindBy(xpath="//div[text()='Paid Bookings']")
	WebElement paidbookings;
	@FindBy(xpath="//a[contains(text(),' Invoice')]")
	WebElement invoice;
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	WebElement cancelled;
	@FindBy(xpath="//button[@class='btn btn-danger mdc-ripple-upgraded']")
	WebElement delete;
	
	@FindBy(xpath="//div[@class='icon-circle bg-warning text-white']")
	WebElement pending;
	@FindBy(xpath="//select[@id='booking_status']")
	WebElement pendingdrop;
	@FindBy(xpath="//select[@id='booking_status']//following::option[@class='Confirmed']")
	WebElement confirmed;
	@FindBy(xpath="//a[@class='nav-link'][text()='Website']")
	WebElement website;
	
	public AdminHomePg()
	{
		PageFactory.initElements(driver, this);
	}

	public void Bookings() throws Exception
	{
		Thread.sleep(1000);
		Bookings.click();
		Thread.sleep(2000);
	}
	
	public void BookingInv() throws Exception
	{
		paidbookings.click();
		Thread.sleep(1000);
		invoice.click();
		Thread.sleep(1000);
	}
	
	public void Delete() throws Exception
	{
		cancelled.click();
		Thread.sleep(1000);
		delete.click();
		Thread.sleep(1000);
	}
	
	public void Confirm() throws Exception
	{
		pending.click();
		Thread.sleep(1000);
		pendingdrop.click();
		Thread.sleep(1000);
		confirmed.click();
		Thread.sleep(2000);
	}
	
	public void Website() throws Exception
	{
		website.click();
		Thread.sleep(2000);
	}
	
}

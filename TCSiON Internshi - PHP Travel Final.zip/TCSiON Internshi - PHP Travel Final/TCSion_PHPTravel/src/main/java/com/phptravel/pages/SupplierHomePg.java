package com.phptravel.pages;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.phptravel.testbase.TestBase;

public class SupplierHomePg extends TestBase
{
	public int pendingCount;
	public int pendingCountNew;
	
	@FindBy(xpath="//h1[text()='Dashboard']")
	WebElement dashboardTxt;
	@FindBy(xpath="//div[@class='text-muted']")
	WebElement salesTxt;
	@FindBy(xpath="//h2[contains(text(),'Revenue Breakdown')]")
	WebElement revenueBTxt;
	@FindBy(xpath="//div[text()='Pending Bookings']")
	WebElement pendingBookingTab;
	@FindBy(xpath="//div[@class='row gx-3']/div[2]//following::div[@class='display-5']")
	WebElement pendingBookingCount;
	@FindBy(xpath="//table[@id='data']/tbody/tr")
	List<WebElement> totPendingBookings1;
	@FindBy(xpath="//table[@id='data']/tbody/tr/td")
	WebElement noBookingsTxt;
	@FindBy(xpath="//table[@id='data']//following::select[@id='booking_status']")
	List<WebElement> bookingStatusDD;
	@FindBy(xpath="//div[text()='Dashboard']")
	WebElement dashboardLink;

	
	@FindBy(xpath="//a[@class='loadeffect nav-link collapsed mdc-ripple-upgraded']")
	WebElement bookingsLink;
	
	public SupplierHomePg()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String dashboardText()
	{
		return dashboardTxt.getText();
	}
	public String salesText()
	{
		return salesTxt.getText();
	}
	public String revenueBreakdownText() throws Exception
	{
		Thread.sleep(2000);
		return revenueBTxt.getText();
	}
	public int pendingBookingCount()
	{
		String count=pendingBookingCount.getText();		
		pendingCount=Integer.parseInt(count);
		return pendingCount;
	}
	public int clickPending() throws Exception
	{
		int TPB=totPendingBookings1.size();
		int newTPB=TPB-1;
		pendingBookingTab.click();	
		System.out.println("totpendings inside pending pg: "+totPendingBookings1.size());
		String noPendingsText=noBookingsTxt.getText();
		if(noPendingsText.equalsIgnoreCase("No data available in table"))
		{
			System.out.println("No Pending Booking are there!!!.....");
		}
		else if(newTPB>0)
		{
			for(int i=0;i<totPendingBookings1.size();)
			{
				Select drop = new Select(bookingStatusDD.get(i));
				 Thread.sleep(1000);
			    drop.selectByVisibleText("Confirmed");
			    Thread.sleep(2000);
			    pendingCountNew=pendingCount-1;
			    break;
			}
		}
		dashboardLink.click();
		return pendingCountNew;
	}

	public String linkExistOrNot(String linkText) throws Exception
	{
		if(linkText.equals("Bookings"))
		
		{
			driver.findElement(By.xpath("//div[@class='nav']/a[contains(.,'"+linkText+"')]")).click();
			Thread.sleep(2000);
		}
		else if(linkText.equals("tours"))
		{
			driver.findElement(By.xpath("//div[@class='nav']/a[contains(.,'"+linkText+"')]")).click();
			driver.findElement(By.xpath("//div[@id='toursmodule']//a[contains(.,' Tours')]")).click();
		}
		else  if(linkText.equals("Flights"))
		{
			SoftAssert assertion= new SoftAssert();
			assertion.assertFalse(!(driver.findElement(By.xpath("//div[@class='nav']/a[contains(.,'"+linkText+"')]")).getText()).equals("Flights"));
			assertion.assertAll();
		}
		else  if(linkText.equals("Visa"))
		{
			SoftAssert assertion= new SoftAssert();
			assertion.assertFalse(!(driver.findElement(By.xpath("//div[@class='nav']/a[contains(.,'"+linkText+"')]")).getText()).equals("Visa"));
			assertion.assertAll();
		}
		return driver.getCurrentUrl();
	}

}

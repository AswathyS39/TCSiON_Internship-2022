package com.phptravel.pages;


import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.phptravel.testbase.TestBase;

public class CustomerHomePg extends TestBase
{
	@FindBy(xpath="//div[@class='sidebar-menu-wrap']//a[contains(text(),' My Bookings')]")
	WebElement myBookingsLink;
	
	@FindBy(xpath="//li[@class='user_wallet ']/a[contains(text(),' Add Funds')]")
	WebElement addFundsLink;
	@FindBy(xpath="//input[@id='gateway_paypal']")
	WebElement paypalRB;
	@FindBy(xpath="//input[@name='price']")
	WebElement amountTB;
	@FindBy(xpath="//button[@type='submit']")
	WebElement payNowBtn;
	@FindBy(xpath="//div[@role='link']")
	WebElement paypalBtn;	
	@FindBy(xpath="//div[@class='btn']")
	WebElement backToInvoiceBtn;
	
	@FindBy(xpath="//a[text()='Yes']")
	WebElement confirmBtn;
	@FindBy(xpath="//div[@class='sidebar-menu-wrap']//a[contains(text(),' My Profile')]")
	WebElement myProfileLink;
	@FindBy(xpath="//input[@name='address1']")
	WebElement addr1TB;
	@FindBy(xpath="//input[@name='address2']")
	WebElement addr2TB;
	@FindBy(xpath="//button[@type='submit'][text()='Update Profile']")
	WebElement updateBtn;
	@FindBy(xpath="//div[@class='alert alert-success']")
	WebElement updateStatusTxt;
	
	
	@FindBy(xpath="//div[@class='sidebar-menu-wrap']//a[contains(text(),' Logout')]")
	WebElement logoutLink;
	
	@FindBy(xpath="//tbody/tr")
	List<WebElement> totBookings;
	@FindBy(xpath="//tbody/tr//following::div[@class='table-content']/a")
	List<WebElement> totVouchers;
	
	public CustomerHomePg()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void status(String addrUrl) throws Exception
	{
		HttpURLConnection c=(HttpURLConnection)new URL(addrUrl).openConnection();
		System.out.println("c:"+c);
		      // set the HEAD request with setRequestMethod
		      c.setRequestMethod("HEAD");
		      // connection started and get response code
		      c.connect();
		      int r = c.getResponseCode();
		      System.out.println("Http response code: " + r);
	}
	public String clickMyBookingsLink() throws Exception
	{
		myBookingsLink.click();
		Thread.sleep(1000);
		return driver.getCurrentUrl();
	}
	public void clickVoucher() throws Exception
	{
		int totBookingsCount=totBookings.size();
		System.out.println(totBookingsCount);
		if(totBookingsCount>=1)
		{
			for(int i=0;i<totBookingsCount;)
			{
				totVouchers.get(i).click();
				Thread.sleep(2000);
				break;
			}
		}
		else
		{
			System.out.println("No Booking are there!!!.....");
		}
	}
	
	public String addFunds() throws Exception
	{
		addFundsLink.click();
		String addFundsUrl=driver.getCurrentUrl();
		return addFundsUrl;
	}
	public void clickPaynow(int amount) throws Exception
	{
		paypalRB.click();
		Thread.sleep(1000);
		amountTB.clear();
		amountTB.sendKeys(""+amount);
		Thread.sleep(1000);
		payNowBtn.click();
		Thread.sleep(1000);
		paypalBtn.click();
		Thread.sleep(1000);
	}
	
	public String clickBackToInvoice() throws Exception
	{
		backToInvoiceBtn.click();
		Thread.sleep(2000);
		confirmBtn.click();
		String addFundsUrl=driver.getCurrentUrl();
		return addFundsUrl;
	}
	
	public String clickMyProfile() throws Exception
	{
		myProfileLink.click();
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}

	public String updateAddress(String address1, String address2) throws Exception
	{
		addr1TB.clear();
		addr1TB.sendKeys(address1);
		addr2TB.clear();
		addr2TB.sendKeys(address1);
		Thread.sleep(2000);
		JavascriptExecutor ex = (JavascriptExecutor)driver;
		ex.executeScript("scroll(0, 500)");
		ex.executeScript("arguments[0].click()", updateBtn);
		Thread.sleep(1000);
		return updateStatusTxt.getText();
	}
	
	public String clickLogout() throws Exception
	{
		logoutLink.click();	
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}

}

package com.phptravel.pages;

import java.net.HttpURLConnection;
import java.net.URL;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.phptravel.testbase.TestBase;

public class AgentHomePg extends TestBase
{
	@FindBy(xpath="//div[@class='sidebar-menu-wrap']//a[contains(text(),' My Bookings')]")
	WebElement myBookingsLink;
	@FindBy(xpath="//li[@class='user_wallet ']/a[contains(text(),' Add Funds')]")
	WebElement addFundsLink;
	@FindBy(xpath="//div[@class='sidebar-menu-wrap']//a[contains(text(),' My Profile')]")
	WebElement myProfileLink;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement homeLink;
	@FindBy(xpath="//a[text()='Hotels']")
	WebElement hotelsLink;	
	@FindBy(xpath="//a[text()='flights']")
	WebElement flightsLink;
	@FindBy(xpath="//a[text()='Tours']")
	WebElement tourLink;
	@FindBy(xpath="//a[text()='visa']")
	WebElement visaLink;
	@FindBy(xpath="//a[text()='Blog']")
	WebElement blogLink;
	@FindBy(xpath="//a[text()='Offers']")
	WebElement offersLink;

	public AgentHomePg()
	{
		PageFactory.initElements(driver, this);
	}
	public int status(String addrUrl) throws Exception
	{
		URL link= new URL(addrUrl);
		HttpURLConnection httpConnection=(HttpURLConnection) link.openConnection();
		Thread.sleep(2000);
		httpConnection.connect();
		int responseCode=httpConnection.getResponseCode();
		if(responseCode>=400)
		{
			System.out.println(addrUrl +" - "+ "is broken link");	
		}
		else
		{
			System.out.println(addrUrl +" - "+ "is valid link");	
		}
		return responseCode;
	}
	public String clickMyBookingsLink() throws Exception
	{
		myBookingsLink.click();
		System.out.println("My Bookings Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickAddFundsLink() throws Exception
	{
		addFundsLink.click();
		System.out.println("Add Funds Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickMyProfileLink() throws Exception
	{
		myProfileLink.click();	
		System.out.println("My Profile Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickHomeLink() throws Exception
	{
		homeLink.click();	
		System.out.println("Home Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}	
	public String clickFlightsLink() throws Exception
	{
		flightsLink.click();	
		System.out.println("Flights Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickTourLink() throws Exception
	{
		tourLink.click();	
		System.out.println("Tour Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickVisaLink() throws Exception
	{
		visaLink.click();	
		System.out.println("Visa Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickBlogLink() throws Exception
	{
		blogLink.click();	
		System.out.println("Blog Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public String clickOffersLink() throws Exception
	{
		offersLink.click();	
		System.out.println("Offer Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return driver.getCurrentUrl();
	}
	public AgentHotelCurrencyPg clickHotelsLink() throws Exception
	{
		hotelsLink.click();	
		System.out.println("Hotel Link status: "+status(driver.getCurrentUrl()));
		Thread.sleep(2000);
		return new AgentHotelCurrencyPg();
	}	
}

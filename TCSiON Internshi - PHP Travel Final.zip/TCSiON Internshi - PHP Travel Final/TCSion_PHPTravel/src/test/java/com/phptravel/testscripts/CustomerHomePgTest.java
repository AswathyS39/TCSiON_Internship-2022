package com.phptravel.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.CustomerHomePg;
import com.phptravel.testbase.TestBase;
import com.phptravel.utilities.ExcelUtility;

public class CustomerHomePgTest extends TestBase
{
	CustomerHomePg objCustHomepg;
	
	@Test(priority=0)
	public void testMyBookingsLink() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String expectedUrl=objCustHomepg.clickMyBookingsLink();
		String actualUrl=prop.getProperty("customermybookingsurl");
		Assert.assertEquals(expectedUrl, actualUrl);
	}

	@Test(priority=1)
	public void testDisplayVoucher() throws Exception
	{
		
		objCustHomepg = new CustomerHomePg();
		String parent=driver.getWindowHandle();
		objCustHomepg.clickVoucher();
		Thread.sleep(2000);
		String parent2=driver.getCurrentUrl();
		System.out.println("url1:"+parent2);
		driver.switchTo().window(parent);
		Thread.sleep(1000);

	}
	@Test(priority=2)
	public void testAddFunds() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String expectedUrl=objCustHomepg.addFunds();
		String actualUrl=prop.getProperty("addfundsurl");
		Assert.assertEquals(expectedUrl, actualUrl);
	}
	@Test(priority=3)
	public void testWalletPayment() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		objCustHomepg.clickPaynow(50);
	}
	
	@Test(priority=4)
	public void testBack2Invc() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String expectedUrl=objCustHomepg.clickBackToInvoice();
		String actualUrl=prop.getProperty("addfundsurl");
		Assert.assertEquals(expectedUrl, actualUrl);
		Thread.sleep(2000);
	}
	@Test(priority=5)
	public void testMyProfileLink() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String expectedUrl=objCustHomepg.clickMyProfile();
		String actualUrl=prop.getProperty("myprofileurl");
		Assert.assertEquals(expectedUrl, actualUrl);
		Thread.sleep(1000);
	}
	@Test(priority=6)
	public void testMyProfileAddrUpdate() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String addr1=ExcelUtility.getCellData(1, 0);
		String addr2=ExcelUtility.getCellData(1, 1);
		String expectedUpdateMsg=objCustHomepg.updateAddress(addr1, addr2);
		String actualUpdateMsg=AutomationConstants.PROFILE_UPDATED_MSG;
		Assert.assertEquals(expectedUpdateMsg, actualUpdateMsg);
		Thread.sleep(1000);
	}
	
	@Test(priority=7)
	public void logout() throws Exception
	{
		objCustHomepg = new CustomerHomePg();
		String expectedUrl=objCustHomepg.clickLogout();
		String actualUrl=prop.getProperty("customerurl");
		Assert.assertEquals(expectedUrl, actualUrl);
		Thread.sleep(1000);
		
	}
	@Test(priority=8)
	public void tabClose() throws Exception
	{
		String parent=driver.getCurrentUrl();
		System.out.println("url2:"+parent);
		//driver.switchTo().window(child);
		Thread.sleep(1000);
		
	}
}

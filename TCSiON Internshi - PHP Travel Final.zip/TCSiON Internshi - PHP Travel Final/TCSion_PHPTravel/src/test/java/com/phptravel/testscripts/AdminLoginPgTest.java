package com.phptravel.testscripts;

import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.AdminLoginPg;
import com.phptravel.testbase.TestBase;

public class AdminLoginPgTest extends TestBase
{
	AdminLoginPg objDemoLPg;
	@Test(priority=0)
	public void adminLoginClick() throws Exception
	{
		objDemoLPg=new AdminLoginPg();
		String parent=driver.getWindowHandle();
		objDemoLPg.clickAdmin();
		Thread.sleep(1000);
		Set<String> allWindows=driver.getWindowHandles();
		//int count= allWindows.size();
		
		for(String child:allWindows)
		{
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
				String expectedUrl=driver.getCurrentUrl();
				String actualUrl=prop.getProperty("adminurl");
				Assert.assertEquals(expectedUrl, actualUrl);
				Thread.sleep(2000);
			}
		}		
	}
	@Test(priority=1)
	public void invalidUsername() throws Exception
	{
		objDemoLPg=new AdminLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("admin123@phptravels.com");
		objDemoLPg.setPassword("demoadmin");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE1;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
		
	}
	@Test(priority=2)
	public void invalidPassword() throws Exception
	{
		
		objDemoLPg=new AdminLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("admin@phptravels.com");
		objDemoLPg.setPassword("demoadmin123");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE1;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
		
	}
	@Test(priority=3)
	public void nullUsername() throws Exception
	{
		objDemoLPg=new AdminLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("");
		objDemoLPg.setPassword("demoadmin");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String actualNullErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE_S_EMAIL;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
		
	}
	@Test(priority=4)
	public void nullPassword() throws Exception
	{
		objDemoLPg=new AdminLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("admin@phptravels.com");
		objDemoLPg.setPassword("");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String actualNullErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE_S_PSWD;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
		
	}
	@Test(priority=5)
	public void validLogin() throws Exception
	{
		objDemoLPg=new AdminLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("admin@phptravels.com");
		objDemoLPg.setPassword("demoadmin");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String expectedUrl=driver.getCurrentUrl();
		Thread.sleep(2000);
		String actualUrl=prop.getProperty("admindashboard");
		Assert.assertEquals(actualUrl, expectedUrl);
	}

}

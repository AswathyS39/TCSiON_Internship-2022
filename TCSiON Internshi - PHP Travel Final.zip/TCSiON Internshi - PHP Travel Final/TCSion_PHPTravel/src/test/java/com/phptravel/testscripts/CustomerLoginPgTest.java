package com.phptravel.testscripts;

import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.CustomerLoginPg;
import com.phptravel.testbase.TestBase;

public class CustomerLoginPgTest extends TestBase
{

	CustomerLoginPg objDemoLPg;
	@Test(priority=0)
	public void customerLoginClick() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		String parent=driver.getWindowHandle();
		objDemoLPg.clickCustomer();
		Thread.sleep(1000);
		Set<String> allWindows=driver.getWindowHandles();
		//int count= allWindows.size();
		
		for(String child:allWindows)
		{
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
				String expectedUrl=driver.getCurrentUrl();
				String actualUrl=prop.getProperty("customerurl");
				Assert.assertEquals(expectedUrl, actualUrl);
				Thread.sleep(2000);
			}
		}		
	}
	
	@Test(priority=1)
	public void invalidUsername() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		objDemoLPg.setEmail("user123@phptravels.com");
		objDemoLPg.setPassword("demouser");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=2)
	public void invalidPassword() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		objDemoLPg.setEmail("user@phptravels.com");
		objDemoLPg.setPassword("demouser123");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objDemoLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=3)
	public void nullUsername() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		objDemoLPg.setEmail("");
		objDemoLPg.setPassword("demouser");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String actualNullErrorMsg=objDemoLPg.nullEmailErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=4)
	public void nullPassword() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("user@phptravels.com");
		objDemoLPg.setPassword("");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String actualNullErrorMsg=objDemoLPg.nullPassErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=5)
	public void validLogin() throws Exception
	{
		objDemoLPg=new CustomerLoginPg();
		objDemoLPg.clearTB();
		objDemoLPg.setEmail("user@phptravels.com");
		objDemoLPg.setPassword("demouser");
		Thread.sleep(2000);
		objDemoLPg.clickLogin();
		String expectedUrl=driver.getCurrentUrl();
		Thread.sleep(2000);
		String actualUrl=prop.getProperty("customerdashboard");
		Assert.assertEquals(actualUrl, expectedUrl);
	}
}
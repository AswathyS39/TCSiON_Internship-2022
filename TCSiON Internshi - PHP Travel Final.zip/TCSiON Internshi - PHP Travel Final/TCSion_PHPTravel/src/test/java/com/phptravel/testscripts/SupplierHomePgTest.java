package com.phptravel.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.SupplierHomePg;
import com.phptravel.testbase.TestBase;

public class SupplierHomePgTest extends TestBase
{
	SupplierHomePg objSupplierHPg;
	
	@Test(priority=0)
	public void dashboardTextVerify()
	{
		objSupplierHPg = new SupplierHomePg();
		String expResult=objSupplierHPg.dashboardText();
		String actualResult=AutomationConstants.DASHBOARD_TEXT;
		Assert.assertEquals(expResult, actualResult);
	}
	@Test(priority=1)
	public void salesTextVerify()
	{
		objSupplierHPg = new SupplierHomePg();
		String expResult=objSupplierHPg.salesText();
		String actualResult=AutomationConstants.SALES_TEXT;
		Assert.assertEquals(expResult, actualResult);
	}
	@Test(priority=2)
	public void revenueBreakTextVerify() throws Exception
	{
		objSupplierHPg = new SupplierHomePg();
		String expResult=objSupplierHPg.revenueBreakdownText();
		String actualResult=AutomationConstants.REVENUE_BREAKDOWN_TEXT;
		Assert.assertEquals(expResult, actualResult);
	}
	@Test(priority=3)
	public void pendingBookingsOperationTest() throws Exception
	{
		objSupplierHPg = new SupplierHomePg();
		int beforePendingBookingCount=objSupplierHPg.pendingBookingCount();
		System.out.println("Total Count of Pending Bookings before: "+beforePendingBookingCount);
		int afterPendingBookingCount=objSupplierHPg.clickPending();
		System.out.println("Total Count of Pending Bookings after: "+afterPendingBookingCount);
		Assert.assertEquals(beforePendingBookingCount-1, afterPendingBookingCount);
	}
	
	@Test(priority=4)
	public void testToursLink() throws Exception
	{
		objSupplierHPg = new SupplierHomePg();
		objSupplierHPg.linkExistOrNot("tours");
		Thread.sleep(1000);
	}
	@Test(priority=5)
	public void testBookingsLink() throws Exception
	{
		objSupplierHPg = new SupplierHomePg();
		SoftAssert assertion= new SoftAssert();
		objSupplierHPg.linkExistOrNot("Bookings");
		String expResult=driver.getCurrentUrl();
		assertion.assertFalse(driver.getTitle().equalsIgnoreCase("error"));
		assertion.assertAll();
		String actualResult=prop.getProperty("supplierbookingsurl");
		Assert.assertEquals(expResult, actualResult);
		Thread.sleep(1000);
	}	
	@Test(priority=6)
	public void testFlightsLink() throws Exception
	{
		driver.navigate().back();
		objSupplierHPg = new SupplierHomePg();
		objSupplierHPg.linkExistOrNot("Flights");
		Thread.sleep(1000);
	}
	@Test(priority=7)
	public void testVisaLink() throws Exception
	{
		objSupplierHPg = new SupplierHomePg();
		objSupplierHPg.linkExistOrNot("Visa");
		Thread.sleep(1000);
	}
		

}

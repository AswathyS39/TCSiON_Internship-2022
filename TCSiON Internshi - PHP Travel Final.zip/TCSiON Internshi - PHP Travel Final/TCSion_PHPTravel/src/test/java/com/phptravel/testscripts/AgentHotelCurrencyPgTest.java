package com.phptravel.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.pages.AgentHotelCurrencyPg;
import com.phptravel.testbase.TestBase;

public class AgentHotelCurrencyPgTest extends TestBase
{
	AgentHotelCurrencyPg objAgentHotelPg;
	@Test(priority=0)
	public void currencyChngTest() throws Exception
	{
		objAgentHotelPg=new AgentHotelCurrencyPg();
		String expectedCurrency=objAgentHotelPg.currencyINR();
		String actualCurrency="INR";
		Assert.assertEquals(expectedCurrency, actualCurrency);
	}
	@Test(priority=1)
	public void hotel() throws Exception
	{
		objAgentHotelPg=new AgentHotelCurrencyPg();
		objAgentHotelPg.searchHotels("Dubai","Dubai,United Arab Emirates","May 2022","15","20");
	}
	@Test(priority=2)
	public void logout() throws Exception
	{
		objAgentHotelPg = new AgentHotelCurrencyPg();
		String expectedUrl=objAgentHotelPg.clickLogout();
		String actualUrl=prop.getProperty("customerurl");
		Assert.assertEquals(expectedUrl, actualUrl);
		Thread.sleep(1000);
		
	}

}

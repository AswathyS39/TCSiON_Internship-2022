package com.phptravel.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.pages.AgentHomePg;
import com.phptravel.testbase.TestBase;

public class AgentHomePgTest extends TestBase
{
	AgentHomePg objAgentHPg;
	
	@Test(priority=0)
	public void testLinks1() throws Exception
	{
		objAgentHPg=new AgentHomePg();
		String expectedUrl1=objAgentHPg.clickMyBookingsLink();
		String actualUrl1=prop.getProperty("customermybookingsurl");
		Assert.assertEquals(expectedUrl1, actualUrl1);
		
		String expectedUrl2=objAgentHPg.clickAddFundsLink();
		String actualUrl2=prop.getProperty("addfundsurl");
		Assert.assertEquals(expectedUrl2, actualUrl2);
		String expectedUrl3=objAgentHPg.clickMyProfileLink();
		String actualUrl3=prop.getProperty("myprofileurl");
		Assert.assertEquals(expectedUrl3, actualUrl3);
	}
	@Test(priority=1)
	public void testLinks2() throws Exception
	{
		objAgentHPg=new AgentHomePg();
		
		String expectedUrl1=objAgentHPg.clickHomeLink();
		String actualUrl1=prop.getProperty("agenthomeurl");
		Assert.assertEquals(expectedUrl1, actualUrl1);
		
		String expectedUrl2=objAgentHPg.clickFlightsLink();
		String actualUrl2=prop.getProperty("agentflightlinkurl");
		Assert.assertEquals(expectedUrl2, actualUrl2);
		
		String expectedUrl3=objAgentHPg.clickTourLink();
		String actualUrl3=prop.getProperty("agenttourlinkurl");
		Assert.assertEquals(expectedUrl3, actualUrl3);
		
		String expectedUrl4=objAgentHPg.clickVisaLink();
		String actualUrl4=prop.getProperty("agentvisalinkurl");
		Assert.assertEquals(expectedUrl4, actualUrl4);
		
		String expectedUrl5=objAgentHPg.clickBlogLink();
		String actualUrl5=prop.getProperty("agentbloglinkurl");
		Assert.assertEquals(expectedUrl5, actualUrl5);
		
		String expectedUrl6=objAgentHPg.clickOffersLink();
		String actualUrl6=prop.getProperty("agentofferlinkurl");
		Assert.assertEquals(expectedUrl6, actualUrl6);
		
		objAgentHPg.clickHotelsLink();
	}
}

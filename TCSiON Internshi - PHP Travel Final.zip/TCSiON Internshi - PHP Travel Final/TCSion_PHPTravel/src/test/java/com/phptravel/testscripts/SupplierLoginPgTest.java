package com.phptravel.testscripts;

import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.SupplierLoginPg;
import com.phptravel.testbase.TestBase;

public class SupplierLoginPgTest extends TestBase
{
	SupplierLoginPg objSupplierLPg;
	@Test(priority=1)
	public void supplierLoginClick() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		String parent=driver.getWindowHandle();
		objSupplierLPg.clickSupplier();
		Thread.sleep(1000);
		Set<String> allWindows=driver.getWindowHandles();
		//int count= allWindows.size();
		
		for(String child:allWindows)
		{
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
				String expectedUrl=driver.getCurrentUrl();
				String actualUrl=prop.getProperty("supplierurl");
				Assert.assertEquals(expectedUrl, actualUrl);
				Thread.sleep(2000);
			}
		}	
	}

	@Test(priority=2)
	public void invalidUsername() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		objSupplierLPg.clearTB();
		objSupplierLPg.setEmail("supplier123@phptravels.com");
		objSupplierLPg.setPassword("demosupplier");
		Thread.sleep(1000);
		objSupplierLPg.clickLogin();
		Thread.sleep(1000);
		String actualInvalidErrorMsg=objSupplierLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE1;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=3)
	public void invalidPassword() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		objSupplierLPg.clearTB();
		objSupplierLPg.setEmail("supplier@phptravels.com");
		objSupplierLPg.setPassword("demosupplier123");
		Thread.sleep(1000);
		objSupplierLPg.clickLogin();
		Thread.sleep(1000);
		String actualInvalidErrorMsg=objSupplierLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE1;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=4)
	public void nullUsername() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		objSupplierLPg.clearTB();
		objSupplierLPg.setEmail("");
		objSupplierLPg.setPassword("demosupplier");
		Thread.sleep(2000);
		objSupplierLPg.clickLogin();
		String actualNullErrorMsg=objSupplierLPg.nullEmailErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE_S_EMAIL;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=5)
	public void nullPassword() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		objSupplierLPg.clearTB();
		objSupplierLPg.setEmail("supplier@phptravels.com");
		objSupplierLPg.setPassword("");
		Thread.sleep(1000);
		objSupplierLPg.clickLogin();
		String actualNullErrorMsg=objSupplierLPg.nullPassErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE_S_PSWD;
		Thread.sleep(1000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=6)
	public void validLogin() throws Exception
	{
		objSupplierLPg=new SupplierLoginPg();
		objSupplierLPg.clearTB();
		objSupplierLPg.setEmail("supplier@phptravels.com");
		objSupplierLPg.setPassword("demosupplier");
		Thread.sleep(1000);
		objSupplierLPg.clickLogin();
		Thread.sleep(2000);
		String expectedUrl=driver.getCurrentUrl();
		String actualUrl=prop.getProperty("supplierdashboard");
		Assert.assertEquals(actualUrl, expectedUrl);
	}
}

package com.phptravel.testscripts;

import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravel.constants.AutomationConstants;
import com.phptravel.pages.AgentLoginPg;
import com.phptravel.testbase.TestBase;

public class AgentLoginPgTest extends TestBase
{
	AgentLoginPg objAgentLPg;
	
	@Test(priority=0)
	public void customerLoginClick() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		String parent=driver.getWindowHandle();
		objAgentLPg.clickAgent();
		Thread.sleep(1000);
		Set<String> allWindows=driver.getWindowHandles();
		//int count= allWindows.size();
		
		for(String child:allWindows)
		{
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
				String expectedUrl=driver.getCurrentUrl();
				String actualUrl=prop.getProperty("agenturl");
				Assert.assertEquals(expectedUrl, actualUrl);
				Thread.sleep(2000);
			}
		}		
	}

	@Test(priority=1)
	public void invalidUsername() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		objAgentLPg.setEmail("agent123@phptravels.com");
		objAgentLPg.setPassword("demoagent");
		Thread.sleep(2000);
		objAgentLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objAgentLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=2)
	public void invalidPassword() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		objAgentLPg.setEmail("agent@phptravels.com");
		objAgentLPg.setPassword("demoagent123");
		Thread.sleep(2000);
		objAgentLPg.clickLogin();
		Thread.sleep(2000);
		String actualInvalidErrorMsg=objAgentLPg.invalidLoginMsg();
		String expectedInvalidErrorMsg=AutomationConstants.INVALID_LOGIN_MESSAGE;
		Assert.assertEquals(actualInvalidErrorMsg, expectedInvalidErrorMsg);
	}
	@Test(priority=3)
	public void nullUsername() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		objAgentLPg.setEmail("");
		objAgentLPg.setPassword("demoagent");
		Thread.sleep(2000);
		objAgentLPg.clickLogin();
		String actualNullErrorMsg=objAgentLPg.nullEmailErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=4)
	public void nullPassword() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		objAgentLPg.clearTB();
		objAgentLPg.setEmail("agent@phptravels.com");
		objAgentLPg.setPassword("");
		Thread.sleep(2000);
		objAgentLPg.clickLogin();
		String actualNullErrorMsg=objAgentLPg.nullPassErrorMsg();
		String expectedNullErrorMsg=AutomationConstants.NULL_LOGIN__MESSAGE;
		Thread.sleep(2000);
		Assert.assertEquals(actualNullErrorMsg, expectedNullErrorMsg);
	}
	@Test(priority=5)
	public void validLogin() throws Exception
	{
		objAgentLPg=new AgentLoginPg();
		objAgentLPg.clearTB();
		objAgentLPg.setEmail("agent@phptravels.com");
		objAgentLPg.setPassword("demoagent");
		Thread.sleep(2000);
		objAgentLPg.clickLogin();
		String expectedUrl=driver.getCurrentUrl();
		Thread.sleep(2000);
		String actualUrl=prop.getProperty("agentdashboard");
		Assert.assertEquals(actualUrl, expectedUrl);
	}
	

}

package com.phptravel.testscripts;

import org.openqa.selenium.Alert;
import org.testng.annotations.Test;

import com.phptravel.pages.AdminHomePg;
import com.phptravel.testbase.TestBase;

public class AdminHomePgTest extends TestBase
{
	AdminHomePg objAdmHomepg;

	@Test(priority=0)
	public void bookings() throws Exception
	{	
		objAdmHomepg = new AdminHomePg();
		Thread.sleep(1000);
		objAdmHomepg.Bookings();
	}
	@Test(priority=1)
	public void bookingInv() throws Exception
	{		
		objAdmHomepg = new AdminHomePg();
		String parent=driver.getWindowHandle();
		objAdmHomepg.BookingInv();
		Thread.sleep(1000);
		driver.switchTo().window(parent);

	}

	@Test(priority=2)
	public void delete() throws Exception
	{		
		objAdmHomepg = new AdminHomePg();
		objAdmHomepg.Delete();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		Thread.sleep(1000);
	}

	@Test(priority=3)
	public void confirm() throws Exception
	{		
		objAdmHomepg = new AdminHomePg();
		objAdmHomepg.Confirm();
	}

	@Test(priority=4)
	public void website() throws Exception
	{		
		objAdmHomepg = new AdminHomePg();
		objAdmHomepg.Website();
		Thread.sleep(2000);
		driver.getCurrentUrl();
	}



}